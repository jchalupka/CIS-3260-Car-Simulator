# Car Simulator

## Build

To build you must install ant.

To build, use the following command in this directory.

```
ant -f . -Dnb.internal.action.name=rebuild clean jar
```

## Run

To run, use the following command:
```
java -jar "dist/CarSimulator.jar"
```

