package carsimulator.carui;

public class Temperature implements Widget {

    public void Draw() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
