package carsimulator.carui;

public class FuelGuage {

    public void Draw() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
