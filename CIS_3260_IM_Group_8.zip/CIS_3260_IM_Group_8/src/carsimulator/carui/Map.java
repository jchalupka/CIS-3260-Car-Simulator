package carsimulator.carui;

/**
 *
 * @author justin
 */
public class Map implements Widget {
    public void Draw() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public void Map() {
        
    }
}
