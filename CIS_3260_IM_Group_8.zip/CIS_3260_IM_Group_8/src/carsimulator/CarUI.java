package carsimulator;

import java.awt.Frame;

public class CarUI extends Frame {
    
}
